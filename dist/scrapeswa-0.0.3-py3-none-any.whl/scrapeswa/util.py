conditions=[]
progressCounter=0
progressTotal=0
